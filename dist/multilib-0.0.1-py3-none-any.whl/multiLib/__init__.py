from .AM import typetall, kvadratrot, variasjonsbredde, gjennomsnitt, median, potens
from .Ge import sjekkVerdi, GetInput
from .PC import wait, shutdown, cancelShutdown, cmd, copy, paste, installPipe